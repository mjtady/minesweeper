Name: Maria Juliana Tady
Section: 10790
UFL email: mtady@ufl.edu
System: Windows
Compiler: mingw
SFML version: 2.5.1
IDE: Clion
Other notes: None
